# AI Tennis Player Assistant

A Gemini-powered tool-using AI agent built in Python. The agent answers tennis questions using a small local knowledge base and demonstrates manual function calling and an agent loop.

## Run in Google Colab
1. Upload `tennis_player_ai_agent.ipynb` to Google Colab.
2. Add a Colab secret named `GEMINI_API_KEY`, or enter your key when prompted.
3. Run the notebook from top to bottom.

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
jupyter notebook tennis_player_ai_agent.ipynb
```

The notebook prompts for the Gemini key securely. Do not commit API keys or `.env` files.

## Features
- Tennis player profiles and playing styles
- Historical Grand Slam achievements
- Player comparisons
- Basic rules and court-surface explanations
- Gemini function calling and a manual agent loop

## Limitations
The included knowledge base is a small educational sample. It does not provide live rankings, live scores, or current-season statistics. Add a trusted data source for live information.
